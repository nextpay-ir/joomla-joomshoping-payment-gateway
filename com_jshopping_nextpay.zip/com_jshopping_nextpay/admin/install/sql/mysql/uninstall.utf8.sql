DROP TABLE `#__jshopping_nextpay`;
DELETE FROM `#__jshopping_payment_method` WHERE `payment_code`='nextpay';