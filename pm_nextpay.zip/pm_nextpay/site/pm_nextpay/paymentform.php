<?php
/**
 * @version      1.0
 * @author       Nextpay
 * @package      Jshopping
 * @copyright    Nextpay.ir.
 * @license      GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
function check_pm_nextpay(){
    jQuery('#payment_form').submit();
}
</script>