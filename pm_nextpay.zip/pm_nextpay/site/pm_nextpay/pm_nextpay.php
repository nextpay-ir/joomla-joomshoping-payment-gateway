<?php
ini_set('display_errors', 1);
defined('_JEXEC') or die('Restricted access');

class pm_nextpay extends PaymentRoot
{

    function showPaymentForm($params, $pmconfigs)
    {
        include(dirname(__FILE__)."/paymentform.php");
    }

    //function call in admin
    function showAdminFormParams($params)
    {
        $array_params = [
            'merchant_id',
            'transaction_end_status',
            'transaction_pending_status',
            'transaction_failed_status'
        ];
        foreach ($array_params as $key) {
            if (!isset($params[$key])) $params[$key] = '';
        }
        $params['currency'] = isset($params['currency']) ? $params['currency'] : "0";
        $orders = JModelLegacy::getInstance('orders', 'JshoppingModel'); //admin model
        include(dirname(__FILE__)."/adminparamsform.php");
    }

    function checkTransaction($pmconfigs, $order, $act)
    {
        $app = JFactory::getApplication();
        $input = $app->input;
        try {

            $api_key = $pmconfigs['merchant_id'];
            $session =& JFactory::getSession();
            $amount = (int)$session->get('amount');
            $trans_id = $input->getString('trans_id');
            $order_id = $order->order_id;

            if ($input->getString('order_id') != $order->order_id)
                throw new Exception("مغایرت در تراکنش ارسالی", 3);

            $verifyContext = compact('api_key', 'amount', 'trans_id', 'order_id');
            $verify = $this->nextPayRequest('verification', $verifyContext);

            if (!$verify)
                throw new Exception("عملیات اعتبارسنجی تراکنش ناموفق بود. اشکالی در ارتباط با نکست پی پیش آمده است.", 3);

            $status = $verify->code;
            if ($status == 0) {
                $transaction = new stdClass();
                $transaction->id = null;
                $transaction->order_id = (string)$order->order_id;
                $transaction->ref_id = (string)$trans_id;
                $transaction->amount = (string)$amount;

                JFactory::getDBO()->insertObject('#__jshopping_nextpay', $transaction);

                $message = "خرید شما موفق بود <br> شماره سفارش شما: {$order->order_id} <br>شماره پیگیری نکست پی: {$trans_id}";
                $app->enqueueMessage($message, 'message');
                return array(1, $message, $trans_id);
            }

            throw new Exception("پرداخت ناموفق :‌ $status", 2);

        } catch (Exception $e) {
            $message = "خطای پیش آمده این است: " . '<br>' . $e->getMessage();
            saveToLog("payment.log", "Status pending. Order ID " . $order->order_id . ". Error Reason: " . $e->getMessage());
            $app->enqueueMessage($message, 'warning');
            return array($e->getCode(), $message);
        }
    }

    function showEndForm($pmconfigs, $order)
    {
        // nextpay request context
        $api_key = $pmconfigs['merchant_id'];
        $amount = $this->nextPayAmount($order->order_total, $pmconfigs['currency']);
        $order_id = $order->order_id;
        $uri = JURI::getInstance();
        $liveurlhost = $uri->toString(array("scheme", 'host', 'port'));
        $callback_uri = $liveurlhost . SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=pm_nextpay");

        $requestContext = compact(
            'api_key',
            'order_id',
            'amount',
            'callback_uri'
        );

        $app = JFactory::getApplication();

        try {
            $request = $this->nextPayRequest('request', $requestContext);

            if (!$request)
                throw new Exception("مشکلی در ارتباط پیش آمده است. لطفا چند دقیقه بعد دوباره امتحان کنید.");

            $status = $request->code;
            if ($status == -1) {
                $session =& JFactory::getSession();
                //$session->set('orderID', $order->order_id);
                $session->set('amount', $amount);

                $nextpayRedirect = "https://api.nextpay.org/gateway/payment/{$request->trans_id}";

                $app->redirect($nextpayRedirect);
                exit;
            }

            throw new Exception("خطا در ارتباط :‌ $status");
        } catch (Exception $e) {
            $message = "خطای پیش آمده این است:" . "<br>" . $e->getMessage();
            $app->enqueueMessage($message, 'warning');
            exit;
        }
    }

    function getUrlParams($pmconfigs)
    {
        $params = array();
        $params['order_id'] = JRequest::getInt("order_id");
        $params['hash'] = "";
        $params['checkHash'] = 0;
        $params['checkReturnParams'] = 1;
        return $params;
    }

    /*
 * make a nextpay soap request
 */
    private function nextPayRequest($type, $context)
    {
        switch ($type)
        {
            case 'request':
                try {
                    $client = new SoapClient('https://api.nextpay.org/gateway/token.wsdl', array('encoding' => 'UTF-8'));
                    $result = $client->TokenGenerator($context);
                    $result = $result->TokenGeneratorResult;
                    return $result;
                } catch (SoapFault $e) {
                    return false;
                }
                break;
            case 'verification':
                try {
                    $client = new SoapClient('https://api.nextpay.org/gateway/verify.wsdl', array('encoding' => 'UTF-8'));
                    $result = $client->PaymentVerification($context);
                    $result = $result->PaymentVerificationResult;
                    return $result;
                } catch (SoapFault $e) {
                    return false;
                }
                break;

        }

    }

    /*
 * detect currency for amount
 */
    private function nextPayAmount($price, $currency)
    {
        if (!(bool)$currency)// $currency == '0' => 'rial'
        {
            $price /= 10;
        }

        return (int)$price;
    }
}